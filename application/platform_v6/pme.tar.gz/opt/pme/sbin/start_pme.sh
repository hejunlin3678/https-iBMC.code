#!/bin/sh

# This scripts kill all pme process and restart them.

# May you do good and not evil.
# May you find forgiveness for yourself and forgive others.
# May you share freely, never taking more than you give.

# author: 
# date: Thu Apr 10 14:59:03 CST 2014
# version: 0.8.1-1

source /opt/pme/sbin/utils.sh

#global var
G_MAIN_DIR=/opt/pme/sbin
G_APP_DIR=/opt/pme/apps
G_APP_COUNT=`count_app`
G_DFM_SHM_ID=""
G_DFM_SHM_KEY="00131231"
G_RPV_DIR=/opt/pme/pram/pme_rpc


# tmp begin
rm -f ${G_APP_DIR}/*.txt >/dev/null 2>&1
rm -f ${G_APP_DIR}/*.log >/dev/null 2>&1
rm -f ${G_APP_DIR}/*.bin >/dev/null 2>&1
rm -f /tmp/fsync_reg.ini >/dev/null
# tmp end

get_dfm_shmid()
{
    G_DFM_SHM_ID=`busybox ipcs | grep -A5 "Shared Memory" | grep "$G_DFM_SHM_KEY" | awk '{print $2}'`
}

stop()
{
    # stop them if they are running.
    # apps
    for line in $(grep -Ev "^$|#" "$G_SRC")
    do
        killall $line >/dev/null 2>&1
    done
	
    # main process
    killall dfm >/dev/null 2>&1
    killall httpd >/dev/null 2>&1
    killall snmpd >/dev/null 2>&1
    
    # clean dfm shared memory
    get_dfm_shmid;
    if [ -n "G_DFM_SHM_ID" ]; then
        busybox ipcrm -m "$G_DFM_SHM_ID"
        if [ $? != 0 ]; then
            echo "clean dfm shared memory failed!"
            exit 1
        fi
    fi

    #remove temp file for rpc
    rm -f ${G_RPV_DIR}/* >/dev/null 2>&1
}

start()
{
    # no append $LD_LIBRARY_PATH
    export LD_LIBRARY_PATH=/opt/pme/lib:/opt/pme/plugins/chip

	#remove temp file for rpc
	rm -f ${G_RPV_DIR}/* >/dev/null 2>&1

    cd "$G_MAIN_DIR"

    # must change dir to G_MAIN_DIR
    # start main process
    ./dfm "$G_APP_COUNT" &
    sleep 2
	
    count=`ps -ef | grep dfm | grep -v "grep" | wc -l`
    if [ $count == 0 ]; then
	    ./dfm "$G_APP_COUNT" &
	    echo "dfm retry..."
	    sleep 2
    fi

    # start apps
    ./run_app.sh
	
    rm -f /opt/pme/web/logs/*.pid >/dev/null 2>&1
}

case "$1" in
start)
    start
    echo start pme
    ;;
restart) 
    stop
    start
    echo restart pme
    ;;
stop) 
    stop
    echo stop pme
    ;;
*)
    echo "Usage: $0 {start|stop|restart}"
    ;;
esac

exit 0

