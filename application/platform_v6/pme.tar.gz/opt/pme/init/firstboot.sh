#!/bin/bash

# This scripts will run at start.sh and before start pme.
# author: 
# date: Sat May 24 11:22:48 CST 2014
# version: 0.8.0-1


# global var define
G_COUNT=34
G_FLAG="/var/firstboot.flag"
G_SYNC_DIR="/opt/pme/conf/data_dir_sync"


# note: every time you edit function sync_cmd, you must ++G_COUNT.
func12()
{
    cp -f /.bash_profile /home/ > /dev/null 2>&1
    cp -f /.bashrc /home/ > /dev/null 2>&1
    
    chmod 644 /data/etc/passwd

    sed -i 's/nobody:x:99:99:Nobody:\/:\/sbin\/nologin/nobody:x:99:0:Nobody:\/:\/sbin\/nologin/' /data/etc/passwd
    cp -f /data/etc/passwd /opt/pme/save/User_passwd.bak
    busybox md5sum /data/etc/passwd | awk '{print $1}' > /opt/pme/save/User_passwd.md5
    busybox md5sum /opt/pme/save/User_passwd.bak | awk '{print $1}' > /opt/pme/save/User_passwd.bak.md5
    rm -f /opt/pme/pram/User_passwd

    sed -i 's/nobody:x:99:/nobody:x:0:/' /data/etc/group
    cp -f /data/etc/group /opt/pme/save/User_group.bak
    busybox md5sum /data/etc/group | awk '{print $1}' > /opt/pme/save/User_group.md5
    busybox md5sum /opt/pme/save/User_group.bak | awk '{print $1}' > /opt/pme/save/User_group.bak.md5
    rm -f /opt/pme/pram/User_group

    sed -i 's/auth        requisite      pam_pme.so/auth        required      pam_pme.so/' /data/etc/pam.d/login

    sed -i 's/requisite    pam_pme.so/required     pam_pme.so/' /data/etc/pam.d/sshd

    sed -i 's/requisite    pam_pme.so/required     pam_pme.so/' /data/etc/pam.d/vsftpd


    if [ ! -d /data/opt/pme/web/conf/ssl.key ]; then
        mkdir /data/opt/pme/web/conf/ssl.key -p
        chmod 750 /data/opt/pme/web/conf/ssl.key
    fi

    sed -i 's/\/opt\/pme\/web\/conf\/ssl\.key\/server\.cert/\/data\/opt\/pme\/web\/conf\/ssl\.key\/server\.pem/' /data/opt/pme/web/conf/extra/httpd-ssl.conf
    sed -i 's/^SSLCertificateKeyFile /#SSLCertificateKeyFile /' /data/opt/pme/web/conf/extra/httpd-ssl.conf

    if [ ! -d /data/opt/pme/conf/network ]; then
        mkdir /data/opt/pme/conf/network -p
        chmod 777 /data/opt/pme/conf/network
    fi

    if [ -f /data/etc/ssh/ssh_host_dsa_key ]; then
        chmod 0400 /data/etc/ssh/ssh_host_dsa_key
    fi
    if [ -f /data/etc/ssh/ssh_host_dsa_key.pub ]; then
        chmod 0400 /data/etc/ssh/ssh_host_dsa_key.pub
    fi
    if [ -f /data/etc/ssh/ssh_host_rsa_key ]; then
        chmod 0400 /data/etc/ssh/ssh_host_rsa_key
    fi
    if [ -f /data/etc/ssh/ssh_host_rsa_key.pub ]; then
        chmod 0400 /data/etc/ssh/ssh_host_rsa_key.pub
    fi

    if [ -f /opt/pme/conf/data_dir_sync/sshd_config ]; then
        cp /opt/pme/conf/data_dir_sync/sshd_config /data/etc/ssh/sshd_config -f
    fi
    if [ -f /opt/pme/conf/data_dir_sync/sysctl.conf ]; then
        cp /opt/pme/conf/data_dir_sync/sysctl.conf /data/etc/ssh/sysctl.conf -f
    fi
}

func13()
{
    patch "$1" /data/opt/pme/web/conf/httpd.conf ${G_SYNC_DIR}/13/httpd.conf.patch

    chmod 640 /data/var/log/pme/security_log >/dev/null 2>&1
    chmod 600 /data/var/log/pme/app_debug_log >/dev/null 2>&1
    chmod 640 /data/var/log/pme/operate_log >/dev/null 2>&1
    chmod 600 /data/var/log/pme/dfm_debug_log >/dev/null 2>&1
    chmod 600 /data/var/log/pme/fdm_log >/dev/null 2>&1
    chmod 600 /data/var/log/pme/reg_info_log >/dev/null 2>&1
    chmod 400 /data/opt/pme/web/conf/ssl.key/server.pfx >/dev/null 2>&1
    chmod 400 /data/opt/pme/conf/customize.pfx >/dev/null 2>&1

}

func14()
{
    chmod 0600 ./data/etc/ssh/sshd_config
    sed -i 's/#LogLevel/LogLevel/' /data/etc/ssh/sshd_config
    if [ "$1" = "-R" ]; then
        sed -i 's/^Ciphers/#Ciphers/' /data/etc/ssh/sshd_config
        sed -i 's/^ClientAliveCountMax/#ClientAliveCountMax/' /data/etc/ssh/sshd_config
        sed -i 's/^Banner/#Banner/' /data/etc/ssh/sshd_config
        sed -i 's/^MaxStartups/#MaxStartups/' /data/etc/ssh/sshd_config
        sed -i 's/^LoginGraceTime.*$//' /data/etc/ssh/sshd_config
    else
        sed -i 's/^#Ciphers/Ciphers/' /data/etc/ssh/sshd_config
        sed -i 's/^#ClientAliveCountMax 3/ClientAliveCountMax 0/' /data/etc/ssh/sshd_config
        sed -i 's/^#Banner.*$/Banner \/etc\/HOSTNAME/' /data/etc/ssh/sshd_config
        sed -i 's/^#MaxStartups.*$/MaxStartups 10:30:100\nLoginGraceTime 120/' /data/etc/ssh/sshd_config
    fi
}

func15()
{
    if [ "$1" = "-R" ]; then
        sed -i 's/^#LoadModule status_module modules\/mod_status\.so/LoadModule status_module modules\/mod_status\.so/' /data/opt/pme/web/conf/httpd.conf
        sed -i 's/#ScriptAlias \/cgi-bin\//ScriptAlias \/cgi-bin\//' /data/opt/pme/web/conf/httpd.conf
        sed -i '/^#<Directory \"\/opt\/pme\/web\/cgi-bin\">/,/<\/Directory>/s/^#//' /data/opt/pme/web/conf/httpd.conf
    else
        sed -i 's/^LoadModule status_module modules\/mod_status\.so/#LoadModule status_module modules\/mod_status\.so/' /data/opt/pme/web/conf/httpd.conf
        sed -i 's/ScriptAlias \/cgi-bin\//#ScriptAlias \/cgi-bin\//' /data/opt/pme/web/conf/httpd.conf
        sed -i '/^<Directory \"\/opt\/pme\/web\/cgi-bin\">/,/<\/Directory>/s/^/#/' /data/opt/pme/web/conf/httpd.conf
    fi

}

func16()
{
    if [ "$1" = "-R" ]; then
        sed -i 's/^#Ciphers /Ciphers /' /data/etc/ssh/sshd_config
        sed -i 's/^#ClientAliveInterval 300$/ClientAliveInterval 300/' /data/etc/ssh/sshd_config
        sed -i 's/^#ClientAliveCountMax 0$/ClientAliveCountMax 0/' /data/etc/ssh/sshd_config
    else
        sed -i 's/^Ciphers /#Ciphers /' /data/etc/ssh/sshd_config
        sed -i 's/^ClientAliveInterval 300$/#ClientAliveInterval 300/' /data/etc/ssh/sshd_config
        sed -i 's/^ClientAliveCountMax 0$/#ClientAliveCountMax 0/' /data/etc/ssh/sshd_config
    fi
}

func17()
{
    if [ "$1" = "-R" ]; then
        # do nothing
        :
    else
        grep '^view.*excluded' /data/etc/snmp/snmpd.conf >/dev/null 2>&1
        if [ $? != 0 ]; then
            sed -i '12 iview   all     excluded                 1.3.6.1.6'  -i /data/etc/snmp/snmpd.conf
        fi
    fi
}

func18()
{
    if [ "$1" = "-R" ]; then
        # do nothing
        :
    else
        if [ -f /data/opt/pme/conf/customize.pfx ]; then
            rm -f /data/opt/pme/conf/customize.pfx
        fi
    fi
}

func19()
{
    if [ "$1" = "-R" ]; then
        # do nothing
        :
    else
        grep '^view.*excluded' /data/etc/snmp/snmpd.conf >/dev/null 2>&1
        if [ $? != 0 ]; then
            sed -i '12 iview   all     excluded                 1.3.6.1.6'  -i /data/etc/snmp/snmpd.conf
            cp -f /data/etc/snmp/snmpd.conf /opt/pme/save/Snmp_snmpd.conf.bak
            busybox md5sum /data/etc/snmp/snmpd.conf | awk '{print $1}' > /opt/pme/save/Snmp_snmpd.conf.md5
            busybox md5sum /opt/pme/save/Snmp_snmpd.conf.bak | awk '{print $1}' > /opt/pme/save/Snmp_snmpd.conf.bak.md5
            rm -f /opt/pme/pram/Snmp_snmpd.conf
        fi
    fi
}

func20()
{
    if [ "$1" = "-R" ]; then
        sed -i 's/^.*AddType application\/x-httpd-php .php .jar .jpeg .html$/    AddType application\/x-httpd-php .php .jar .jpeg/' /data/opt/pme/web/conf/httpd.conf
    else
        sed -i 's/^.*AddType application\/x-httpd-php .php .jar .jpeg$/    AddType application\/x-httpd-php .php .jar .jpeg .html/' /data/opt/pme/web/conf/httpd.conf
    fi
}

func21()
{
    if [ "$1" = "-R" ]; then
        # do nothing
        :
    else
        #PME do not provide ssh key any more
        :
    fi
}

func22()
{
    if [ "$1" = "-R" ]; then
        # do nothing
        :
    else
        sed -i 's/^#Ciphers.*$/Ciphers aes128-cbc,aes128-ctr,aes192-ctr,aes256-ctr,arcfour256,arcfour128/' /data/etc/ssh/sshd_config
    fi
}

func23()
{
    if [ "$1" = "-R" ]; then
        # disable this function
        sed -i 's/^ClientAliveInterval/#ClientAliveInterval/' /data/etc/ssh/sshd_config
        sed -i 's/^ClientAliveCountMax/#ClientAliveCountMax/' /data/etc/ssh/sshd_config
    else
        # enable this function
        sed -i 's/^#ClientAliveInterval.*$/ClientAliveInterval 300/' /data/etc/ssh/sshd_config
        sed -i 's/^#ClientAliveCountMax.*$/ClientAliveCountMax 0/' /data/etc/ssh/sshd_config
    fi
}

func24()
{
    if [ "$1" = "-R" ]; then
        # do nothing
        :
    else
        sed -i 's/^Ciphers.*$/Ciphers aes128-cbc,aes128-ctr,aes192-ctr,aes256-ctr,arcfour256,arcfour128/' /data/etc/ssh/sshd_config
        sed -i 's/^#Ciphers.*$/Ciphers aes128-cbc,aes128-ctr,aes192-ctr,aes256-ctr,arcfour256,arcfour128/' /data/etc/ssh/sshd_config
    fi
}

func25()
{
    if [ "$1" = "-R" ]; then
        # do nothing
        :
    else
        if [ ! -d "/data/opt/pme/web/htdocs/bmc/resources/images/cmn" ]; then
            mkdir -p /data/opt/pme/web/htdocs/bmc/resources/images/cmn
            chmod 777 /data/opt/pme/web/htdocs/bmc/resources/images/cmn
        fi
        if [ ! -f "/data/opt/pme/web/htdocs/bmc/resources/images/cmn/logo.jpg" ]; then
            cp -f /opt/pme/conf/data_dir_sync/25/logo.jpg /data/opt/pme/web/htdocs/bmc/resources/images/cmn/ 
        fi
        if [ ! -f "/data/opt/pme/web/htdocs/favicon.ico" ]; then
            cp -f /opt/pme/conf/data_dir_sync/25/favicon.ico /data/opt/pme/web/htdocs/
        fi
    fi
}

func26()
{
    if [ "$1" = "-R" ]; then
        # do nothing
        :
    else
        sed -i 's/^.*ClientAliveInterval.*$/ClientAliveInterval 900/' /data/etc/ssh/sshd_config
        sed -i 's/^.*ClientAliveCountMax.*$/ClientAliveCountMax 0/' /data/etc/ssh/sshd_config
    fi
}

func27()
{
    if [ "$1" = "-R" ]; then
        sed -i 's/^.*KexAlgorithms .*$//' /data/etc/ssh/sshd_config
    else
        sed -i 's/^.*KexAlgorithms .*$//' /data/etc/ssh/sshd_config
        sed -i '44iKexAlgorithms diffie-hellman-group-exchange-sha1' /data/etc/ssh/sshd_config
    fi
}

func28()
{
    if [ "$1" = "-R" ]; then
        sed -i 's/^Subsystem .*$/Subsystem sftp \/usr\/libexec\/openssh\/sftp-server -l INFO/' /data/etc/ssh/sshd_config
    else
        sed -i 's/^Subsystem .*$/Subsystem sftp internal-sftp -u 0077/' /data/etc/ssh/sshd_config
    fi
}

func29()
{
    if [ "$1" = "-R" ]; then
        sed -i 's/^Subsystem .*$/Subsystem sftp internal-sftp -u 0077/' /data/etc/ssh/sshd_config
    else
        sed -i 's/^Subsystem .*$/Subsystem sftp internal-sftp -l INFO -u 0077/' /data/etc/ssh/sshd_config
    fi
}

func30()
{
    if [ "$1" = "-R" ]; then
        sed -i 's/^Ciphers .*$/Ciphers aes128-cbc,aes128-ctr,aes192-ctr,aes256-ctr,arcfour256,arcfour128/' /data/etc/ssh/sshd_config
    else
        sed -i 's/^Ciphers .*$/Ciphers aes128-cbc,aes128-ctr,aes192-ctr,aes256-ctr/' /data/etc/ssh/sshd_config
    fi
}

func31()
{
    if [ "$1" = "-R" ]; then
        sed -i 's/^KexAlgorithms .*$/KexAlgorithms diffie-hellman-group-exchange-sha1/' /data/etc/ssh/sshd_config
    else
        sed -i 's/^KexAlgorithms .*$/KexAlgorithms diffie-hellman-group-exchange-sha1,diffie-hellman-group14-sha1/' /data/etc/ssh/sshd_config
    fi
}

func32()
{
    if [ "$1" = "-R" ]; then
        # do nothing
        :
    else
        sed -i 's/^#PermitRootLogin yes.*$/PermitRootLogin yes/' /data/etc/ssh/sshd_config
        sed -i 's/^Ciphers.*[ |,]aes128-cbc.*$/Ciphers aes128-ctr,aes192-ctr,aes256-ctr/' /data/etc/ssh/sshd_config
    fi
}

func33()
{
    if [ "$1" = "-R" ]; then
        # do nothing
        :
    else
        sed -i 's/^auth *requisite *pam_securetty.so.*$/#auth requisite pam_securetty.so/' /data/etc/pam.d/login
    fi
}

func34()
{
    if [ "$1" = "-R" ]; then
        # do nothing
        :
    else
        sed -i 's/^#auth *requisite *pam_securetty.so.*$/auth        requisite      pam_securetty.so/' /data/etc/pam.d/login
    fi
}

sync_cmd()
{
    local count=$G_COUNT
    local flag=$(cat "$G_FLAG")

    if [ $flag -lt 12 ]; then
        func12;
    fi

    if [ $flag -lt $count ]; then
        while [ $count -gt $flag ] && [ $count -gt 12 ]; do
            func${count} ""
            let count=count-1
        done
    fi
}

update_flag()
{
    echo "$G_COUNT" > "$G_FLAG"
}


if [ -s /var/firstboot.flag ] && (flag=`cat "$G_FLAG"` && test -n "$flag") && [ "$G_COUNT" = `cat "$G_FLAG"` ]; then
    # do nothing
    :
else
    sync_cmd;
    update_flag;
fi
chmod 640 $G_FLAG

exit 0
