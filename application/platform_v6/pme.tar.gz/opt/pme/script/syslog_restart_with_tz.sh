#!/bin/sh
if [ $# -ne 1 ] ; then
    echo "Usage: $0 time_zone"
    return
fi

echo "options {" > /data/etc/extern.conf
echo "local_time_zone($1);" >> /data/etc/extern.conf
echo "};" >> /data/etc/extern.conf

echo "destination d_pme_dfm_debug { file(\"/var/log/pme/dfm_debug_log\" time_zone($1)); };" >> /data/etc/extern.conf
echo "destination d_pme_security { file(\"/var/log/pme/security_log\" perm(0640) group(200) time_zone($1)); };" >> /data/etc/extern.conf
echo "destination d_kern { file(\"/var/log/pme/linux_kernel_log\" time_zone($1)); };" >> /data/etc/extern.conf

/etc/init.d/syslog-ng restart