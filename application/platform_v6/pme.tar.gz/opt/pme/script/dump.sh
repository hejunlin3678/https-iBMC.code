
#core�ļ�
core_dump="${1}/CoreDump"
mkdir ${core_dump}

cd /var/coredump
ls -t | grep .*-[0-9]*-[0-9]* > ${core_dump}/old_file_list
ls -t | grep -v .*-[0-9]*-[0-9]* > ${core_dump}/new_file_list

while read line
do
    cp ${line} ${core_dump}
done < ${core_dump}/new_file_list

last_file_name=""
while read line
do
        if [ "${last_file_name%-*-*}" != "${line%-*-*}" ]
        then
                cp ${line} ${core_dump}
                last_file_name=${line}
        fi
done < ${core_dump}/old_file_list

rm ${core_dump}/old_file_list ${core_dump}/new_file_list

#�ű�dump
rtos_dump="${1}/RTOSDump"
mkdir "$rtos_dump"

#ϵͳ��Ϣ
sysinfo="$rtos_dump/sysinfo"
mkdir "$sysinfo"
cd "$sysinfo"

cat /proc/meminfo > ./meminfo
df > ./df_info

busybox ipcs -q | grep -v Message | grep -v key  > ./ipcs_q
while read line
do
	if [ -n "$line" ]
	then
		echo "$line" | awk '{print $2}' | xargs busybox ipcs -q -i >> ./ipcs_q_detail
		echo "" >> ./ipcs_q_detail
	fi
done < "./ipcs_q"

busybox ipcs -s | grep -v Semaphore | grep -v key > ./ipcs_s
while read line
do
	if [ -n "$line" ]
	then
		echo "$line" | awk '{print $2}' | xargs busybox ipcs -s -i >> ./ipcs_s_detail
		echo "" >> ./ipcs_s_detail
	fi
done < "./ipcs_s"

#�汾��Ϣ
verinfo="$rtos_dump/versioninfo"
mkdir "$verinfo"
cd "$verinfo"
/opt/pme/bin/ipmcget -d version > ./app_revision.txt  > /dev/null 2>&1
cp /opt/pme/ibmc-revision.txt ./ibmc_revision.txt  > /dev/null 2>&1
cat /opt/pme/app-revision.txt >> ./ibmc_revision.txt  > /dev/null 2>&1
cp /opt/pme/build_date.txt ./  > /dev/null 2>&1

#net
net_info="$rtos_dump/networkinfo"
mkdir "$net_info"
cd "$net_info"
ifconfig > ./ifconfig_info
/opt/pme/bin/ipmcget -d ipinfo > ./ipinfo_info

#driver
drv_info="$rtos_dump/driver_info"
mkdir "$drv_info"
cd "$drv_info"
dmesg > ./dmesg_info
lsmod > ./lsmod_info

echo "cat /proc/ekbox" >> ./kbox_info
cat /proc/ekbox >> ./kbox_info 2>&1
echo "" >> ./kbox_info

echo "cat /proc/kbox/regions/panic" >> ./kbox_info
cat /proc/kbox/regions/panic >> ./kbox_info 2>&1
echo "" >> ./kbox_info
echo "cat /proc/kbox/regions/rsm" >> ./kbox_info
cat /proc/kbox/regions/rsm >> ./kbox_info 2>&1

#��־dump
logdump="${1}/LogDump"
mkdir "$logdump"
cd "$logdump"
cp /var/log/pme/* ./
mkdir "${1}/AppDump" > /dev/null 2>&1
mkdir "${1}/AppDump/dfm" > /dev/null 2>&1
mv ./dfm* "${1}/AppDump/dfm"





