#!/bin/bash
# Copyright (c) Huawei Technologies Co., Ltd. 2012-2020. All rights reserved.
# Description: The shell was used to load rtos_kbox_panic.ko

MODULE="/usr/local/kbox/rtos_kbox_panic"
insmod  "${MODULE}.ko"
