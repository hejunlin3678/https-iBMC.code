#!/bin/sh

PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

# Check user exists, and if so, send sigkill to processes that the user owns

PS_PATH=`which ps`
if [ -z "${PS_PATH}" ]; then
    exit 0
fi

PS_KIND=`ls -l $PS_PATH | grep -o busybox`
RUNNING="0"

if [ "$PS_KIND" == "busybox" ]; then
    USER_ID=`id -u $SUBJECT`
    ps l  > /dev/null 2>&1;
    if [[ $? -eq 0 && -n "$USER_ID" ]]; then
        # busybox's ps output's maximum length of the user field is 8 characters, so use the uid to check.
        RUNNING=`ps l | awk -F ' ' '{print $2}' | grep -Fx "$USER_ID" | wc -l`
    else
        USER_LEN=`echo "$SUBJECT" | wc -L`
        # busybox's ps output's maximum length of the user field is 8 characters, and there is no l option to get uid
        PS_SHOW_LEN="8"
        USER=$SUBJECT

        if [ "$USER_LEN" -gt "$PS_SHOW_LEN" ]; then
            USER=`echo ${SUBJECT:0:8}`
        fi
        RUNNING=`ps | awk -F ' ' '{print $2}' | grep -Fx "$USER" | wc -l`
    fi
else
    RUNNING=`ps -eo user | grep -Fx "$SUBJECT" | wc -l`
fi

# if the user does not exist, RUNNING will be 0

if [ "${RUNNING}x" = "0x" ]; then
  exit 0
fi

ls -1 /proc | while IFS= read -r PROC; do
  echo "$PROC" | grep -E '^[0-9]+$' >/dev/null
  if [ $? -ne 0 ]; then
    continue
  fi
  if [ -d "/proc/${PROC}" ]; then
    USR=`stat -c "%U" /proc/${PROC}`
    if [ "${USR}" = "${SUBJECT}" ]; then
      echo "Killing ${SUBJECT} owned ${PROC}"
      kill -9 "${PROC}"
    fi
  fi
done
