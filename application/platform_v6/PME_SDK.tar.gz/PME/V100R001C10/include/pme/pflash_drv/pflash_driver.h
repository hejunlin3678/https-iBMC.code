/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: pflash_driver.h
 * Author: h00168999
 * Create: 2018/12/22
 * Notes: pflash_driver.h
 * History:
 */

#ifndef __PFLASH_DRV__
#define __PFLASH_DRV__

#include "glib.h"

/* ����flash�ļ�Ŀ¼ */
#ifdef ARM_PLATFORM
    #define RESERVE_FLASH_PATH "/opt/pme/pflash/"
#else
    #define RESERVE_FLASH_PATH "/tmp/pflash/"
#endif

/* ****************************************************************************
�����붨��
**************************************************************************** */
#define PFLASH_OK (0)
#define PFLASH_ELOCK (-3001)  /* �������쳣 */
#define PFLASH_EOPEN (-3002)  /* ���豸�ļ�ʧ�� */
#define PFLASH_EWRITE (-3003) /* д���豸ʧ�� */
#define PFLASH_EERASE (-3004) /* �����豸ʧ�� */
#define PFLASH_EREAD (-3005)  /* ��ȡ�豸�ļ�ʧ�� */
#define PFLASH_ELSEEK (-3006) /* lseek���� */
#define PFLASH_EEXIST (-3007) /* �ļ������� */
#define PFLASH_ECHECK (-3008) /* �ļ��Ա�ʧ�� */
#define PFLASH_EPARA (-3009)  /* �������� */
#define PFLASH_EFULL (-3010)  /* FLASH�� */
#define PFLASH_EFILE (-3011)  /* �ļ��쳣 */

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */


extern gint pflash_recover_file(const gchar *file_name);
extern gint pflash_init(void);
extern gpointer pflash_open(const char *pathname, int flags);
extern gssize pflash_write(gpointer file_hnd, const guint8 *buf, gsize count);
extern gssize pflash_read(gpointer file_hnd, guint8 *buf, gsize count);
extern void pflash_close(gpointer file_hnd);
extern gint pflash_fstat(gpointer file_hnd, gsize *size);
extern gint pflash_get_contents(gpointer file_hnd, guint8 **contents, gsize *length);
extern gint get_pflash_file(gchar *filename, guint8 **contents, gsize *length);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif \
    /* __cplusplus */

#endif
