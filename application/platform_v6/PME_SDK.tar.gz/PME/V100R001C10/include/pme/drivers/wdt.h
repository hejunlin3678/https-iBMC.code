/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: wdt.h
 * Author: h00168999
 * Create: 2018/12/22
 * Notes: wdt.h
 * History:
 */


#ifndef _WDT_H_
#define _WDT_H_

#include "glib.h"

#define WDT_MODE_USER (0)
#define WDT_MODE_KERNEL (1)

#define WDT_ENABLE (1)
#define WDT_DISABLE (0)

/* ****************************************************************************
����ӿں�������, ���Ӷ�C++��֧��
**************************************************************************** */
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

gint32 wdt_mode(guint8 mode);
gint32 stop_wdt(void);
gint32 clear_wdt(void);
gint32 enable_wdt(guint32 enable);
gint32 abnormal_reset(void);
gint32 wait_abnormal_reset(void);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif
