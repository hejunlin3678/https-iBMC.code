/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: adc_base.h
 * Author: h00168999
 * Create: 2018/12/22
 * Notes: adc_base.h
 * History:
 */

#ifndef _CANBUS_BASE_H_
#define _CANBUS_BASE_H_

#include "glib.h"


/* ****************************************************************************
����ӿں�������, ���Ӷ�C++��֧��
**************************************************************************** */
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define CAN_WRITE       0
#define CAN_RESET       1
#define CAN_SET_SPEED   2
#define CAN_SET_ID_MASK 3
#define CAN_FRAME_MIN   4
#define CAN_FRAME_MAX   12

#define CANBUS_ID_INVALID   0xFFFFFFFF  /* ��ЧID�����MASKʹ�ù������н������� */
#define CAN_ID_MASK_ALL     0xFFFFFFFF  /* ����bitƥ��Ž������� */

extern gint32 canbus_init(guchar chan);
extern void canbus_close(guchar chan);
extern gint32 canbus_read(guchar chan, guint8 *obuffer, gint32 len, guint32 time_out);
extern gint32 canbus_write(guchar chan, const guint8 *ibuffer, gint32 len, guint32 time_out);
extern gint32 canbus_reset(guchar chan);
extern gint32 canbus_set_speed(guchar chan, guint32 speed);
extern gint32 canbus_set_id_mask(guchar chan, guint32 id, guint32 mask);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif
