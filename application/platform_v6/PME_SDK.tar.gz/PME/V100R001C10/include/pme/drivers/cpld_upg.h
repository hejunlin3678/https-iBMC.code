/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: cpld_upg.h
 * Author: h00168999
 * Create: 2018/12/22
 * Notes: cpld_upg.h
 * History:
 */


#ifndef _CPLD_UPG_H_
#define _CPLD_UPG_H_

#include "glib.h"

/* ****************************************************************************
�������ݽṹ�ӿں�������
**************************************************************************** */
#define CPLD_UPGRADE_LOAD_MODE (0)
#define CPLD_UPGRADE_RST_MODE (1)
#define MAX_SCAN_CHAIN_SIZE 6

/* ****************************************************************************
�������ݽṹ�ӿں�������
**************************************************************************** */
typedef struct tag_cpld_upg_file_s {
    guint8 mode;
    guint32 product_id;   /* cpld�ļ�id */
    guint32 board_id;     /* board id,���� */
    guint32 pcb;          /* pcb,���� */
    guint32 component_id; /* bit0~23:���ID,0=�װ�cpld��1=����cpld; bit24~31: ���ʹ�õ�ͨ������,0=gpio��1=JLC */
    guint32 length;
    guint8 *buf;
} CPLD_UPG_FILE_S;

typedef struct cpld_device {
    guint8 select;
    guint8 cpld_id;
    guint32 device_count;
    guint32 device_id[MAX_SCAN_CHAIN_SIZE];
} CPLD_DEVICE_S;

/* ****************************************************************************
����ӿں�������, ���Ӷ�C++��֧��
**************************************************************************** */
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

gint32 cpld_reset(void);
gint32 cpld_upg_write(guint8 *buf, guint32 length, guint32 component_id, guint32 product_id);
gint32 cpld_upg_init(guint8 tck, guint8 tms, guint8 tdo, guint8 tdi);
gint32 config_cpld_upg_reg(guint8 offset, guint8 tck, guint8 tms, guint8 tdo, guint8 tdi);
gint32 cpld_reset_init(guint8 rst);
gint32 cpld_upg_init_v2(void);
gint32 cpld_get_id(CPLD_DEVICE_S *cpld_device_s);
gint32 cpld_set_num(guint32 cpld_num);
gint32 cpld_spi_reset(void);    // 1710ʹ��
gint32 cpld_set_jtag_bypass(unsigned char jtag_cmd);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif
