/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: peci.h
 * Author: h00168999
 * Create: 2018/12/22
 * Notes: peci.h
 * History:
 */

#ifndef _PECI_H_
#define _PECI_H_

#include "glib.h"

/* ****************************************************************************
����궨��
**************************************************************************** */
#define PECI_MAX_DATA_NUM (32) /* ��д����������ֽ��� */

/* ****************************************************************************
����ӿ�
**************************************************************************** */
extern gint32 peci_init(void);
extern gint32 peci_write_read(guint8 wr_data[PECI_MAX_DATA_NUM], guint32 wr_len, guint8 rd_data[PECI_MAX_DATA_NUM],
    guint32 *rd_len);

#endif
