/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: pwm_base.h
 * Author: h00168999
 * Create: 2018/12/22
 * Notes: pwm_base.h
 * History:
 */

#ifndef _PWM_H_
#define _PWM_H_

#include "glib.h"

/* ****************************************************************************
�궨��
**************************************************************************** */
#define MAX_PWM_CHAN_NUM (12)
#define MAX_RATIO_PERCENT (1000)

/* ****************************************************************************
���ݽṹ����
**************************************************************************** */
typedef struct tag_pwm_rst_ctrl_s {
    guint32 rst_hold_en; /* PWM����ת�ٸ�λ���ֹ��ܣ� 0 - �ر� 1 - �� */
    guint32 ratio;       /* PWMռ�ձ�(0 - 1000���߾���ģʽ��) */
    guint32 rsvd[2];     /* Reserved for future use */
} PWM_RST_CTRL_S;

/* ****************************************************************************
����ӿں�������, ���Ӷ�C++��֧��
**************************************************************************** */
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

void pwm_clean(void);
gint32 pwm_read(guint32 chanel_num, guint32 *ratio);
gint32 pwm_write(guint32 chanel_num, guint32 ratio);
gint32 pwm_fan_speed_rst_hold(PWM_RST_CTRL_S *rst_ctrl);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif
