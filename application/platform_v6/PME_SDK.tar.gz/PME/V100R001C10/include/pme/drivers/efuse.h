/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: EFUSE��д
 * Author: h00168999
 * Create: 2018/12/22
 * Notes: efuse.h
 * History:
 */

#ifndef _EFUSE_H_
#define _EFUSE_H_

#include "glib.h"

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

gint32 efuse_init(void);
void efuse_clean(void);
gint32 efuse_write(guint8 *efuse_wr_buf, guint32 buf_len);
gint32 efuse_read(guint8 *efuse_wr_buf, guint32 buf_len);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif
