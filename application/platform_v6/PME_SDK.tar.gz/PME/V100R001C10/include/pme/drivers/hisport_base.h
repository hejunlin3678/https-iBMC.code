/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2021-2022. All rights reserved.
 * Description:
 * Author: x00617306
 * Create: 2021/12/08
 * Notes:
 * History:
 */

#ifndef _HISPORT_H_
#define _HISPORT_H_

#include "glib.h"

#define HISPORT_MAX_CHANEL 128

typedef struct tag_hisport_init_s {
    guint32 bus_num;
    guint32 reg_num;
    guint32 flag_num;
    guint32 send_reg_addr;
    guint32 recv_reg_addr;
    guint32 flag_reg_addr;
    guint32 max_batch_len;
    guint32 max_data_len;
    guint32 max_offset_width;
    guint32 max_length_width;
} HISPORT_INIT_S;

typedef struct tag_hisport_s {
    guint32 bus_id;             /* I2C控制器的编号，取值范围为0~(I2C_MAX_CHANEL-1) */
    guint32 addr;               /* 器件地址 */
    guint32 offset;             /* 偏移地址 */
    const guint8 *tx_buffer;    /* 读操作发送的数据，目前不发送，主要用于扩展 */
    guint32 tx_len;             /* 发送命令中数据长度 */
    guint8 *rx_buffer;          /* 回传数据 */
    guint32 rx_len;             /* 回传数据长度 */
    guint8 offset_width;
    guint8 data_width;
    guint8 rw_flag;
    gint32 re_read_cnt;        /* 重读次数 */
    gint32 re_write_cnt;       /* 重写次数 */
} HISPORT_DATA_S;

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

gint32 hisport_default_init(void);
gint32 hisport_init(HISPORT_INIT_S *init_info);
void hisport_clean(void);
gint32 hisport_read(HISPORT_DATA_S *read_data);
gint32 hisport_write(HISPORT_DATA_S *write_data);


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif