/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description:
 * Author: h00168999
 * Create: 2018/12/22
 * Notes:
 * History:
 */

#ifndef _EDMA_H_
#define _EDMA_H_

#include "glib.h"

/*****************************************************************************
����ӿں�������, ���Ӷ�C++��֧��
*****************************************************************************/
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

gint32 edma_open(void);
gint32 edma_close(void);
gint32 edma_snd_data(guint8 *snd_buffer, guint32 snd_len, guint32 timeout);
gint32 edma_rcv_data(guint8 *rcv_buffer, guint32 rcv_len, guint32 *real_rcv_len, guint32 timeout);


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif
