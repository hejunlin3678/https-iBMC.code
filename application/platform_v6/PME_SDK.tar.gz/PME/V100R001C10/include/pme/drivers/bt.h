/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: bt.h
 * Author: h00168999
 * Create: 2018/12/22
 * Notes: bt.h
 * History:
 */

#ifndef _BT_H_
#define _BT_H_

#include "glib.h"

/* ****************************************************************************
�����ṩ��I2C�����궨��
 ***************************************************************************** */
#define MAX_BT_MSG_SIZE (248 + 4)

/* ****************************************************************************
���ݽṹ����
**************************************************************************** */
#pragma pack(1)
typedef struct tag_bt_buffer_info_s {
    guint32 timeout; /* ��ʱʱ�䣬��Χ[0-65535]����λjiffies */
    gchar *buffer;
    guint32 len; /* ��Χ[0-MAX_BT_MSG_SIZE] */
    gint32 reserved;
} BT_BUFFER_INFO_S;
#pragma pack()


/* ****************************************************************************
����ӿں�������, ���Ӷ�C++��֧��
**************************************************************************** */
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

gint32 bt_init(void);
void bt_clean(void);
gint32 bt_read(BT_BUFFER_INFO_S *info);
gint32 bt_write(BT_BUFFER_INFO_S *info);
gint32 bt_setatn(gint32 enable);
gint32 cpld_bt_init(void);
void cpld_bt_clean(void);
gint32 cpld_bt_read(BT_BUFFER_INFO_S *info);
gint32 cpld_bt_write(BT_BUFFER_INFO_S *info);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif
