/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: fantech_base.h
 * Author: h00168999
 * Create: 2018/12/22
 * Notes:
 * History:
 */

#ifndef _FANTECH_H_
#define _FANTECH_H_

#include "glib.h"

/* ****************************************************************************
�궨��
**************************************************************************** */
#define MAX_FANTECH_CHAN_NUM (12)

/* ****************************************************************************
����ӿں�������, ���Ӷ�C++��֧��
**************************************************************************** */
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

void fantech_clean(void);
gint32 fantech_read(guint32 chan_num, guint16 *speed);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif
