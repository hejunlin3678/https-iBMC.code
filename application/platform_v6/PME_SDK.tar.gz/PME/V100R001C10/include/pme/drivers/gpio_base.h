/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description:
 * Author: h00168999
 * Create: 2018/12/22
 * Notes:
 * History:
 */

#ifndef _GPIO_BASE_H_
#define _GPIO_BASE_H_

#include "glib.h"

/* ****************************************************************************
�궨��
**************************************************************************** */
#define GPIO_MAX_GROUP_NUM (5)

/* ****************************************************************************
����ӿں�������, ���Ӷ�C++��֧��
**************************************************************************** */
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

gint32 gpio_init(guint32 gpio_num, guint8 direction);
gint32 gpio_read(guint8 gpio_num, guint8 *gpio_level, guint8 direction);
gint32 gpio_write(guint32 gpio_num, guint8 gpio_level);
gint32 gpio_set_int(guint32 gpio_int_num, guint8 int_level);
gint32 gpio_get_int(guint32 gpio_int_num, guint32 timeout, guint32 *value, guint32 rsv);
gint32 get_io_drive_config(guint8 id, guint8 *value);
gint32 set_io_drive_config(guint8 id, guint8 value);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif
