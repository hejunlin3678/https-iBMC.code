/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: mdio_base.h
 * Author: h00168999
 * Create: 2018/12/22
 * Notes: mdio_base.h
 * History:
 */

#ifndef _MDIO_H_
#define _MDIO_H_

#include "glib.h"

/* ****************************************************************************
����ӿں�������, ���Ӷ�C++��֧��
**************************************************************************** */
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

/* smi read write command */
#define QD_SMI_WRITE 0x01
#define QD_SMI_READ 0x02

#define QD_SMI_CLAUSE45 0
#define QD_SMI_CLAUSE22 1

#define QD_SMI_DEV_ADDR_BIT 5
#define QD_SMI_DEV_ADDR_SIZE 5
#define QD_SMI_REG_ADDR_BIT 0
#define QD_SMI_REG_ADDR_SIZE 5

#define QD_SMI_OP_BIT 10
#define QD_SMI_OP_SIZE 2

#define QD_SMI_BUSY 0x8000
#define QD_SMI_MODE 0x1000
#define QD_SMI_MODE_BIT 12


gint32 mdio_write(guint32 chan_id, guint32 phy_addr, guint32 reg_addr, guint32 value);
gint32 mdio_read(guint32 chan_id, guint32 phy_addr, guint32 reg_addr, guint32 *value);
gint32 mdio_init(void);

gint32 mdio45_read(guint32 chan_id, guint32 phy_addr, guint32 reg_addr, guint32 *value);
gint32 mdio45_write(guint32 chan_id, guint32 phy_addr, guint32 reg_addr, guint32 value);
gint32 mdio45_init(guint32 cpld_cs, guint32 base_addr);


gint32 mdio_multi_read(guint32 lsw_addr, guint32 phy_num, guint32 phy_reg, guint32 *value);
gint32 mdio_multi_write(guint32 lsw_addr, guint32 phy_num, guint32 phy_reg, guint32 data);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif
