/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: platform_hi1710.h
 * Author: h00168999
 * Create: 2018/12/22
 * Notes: platform_hi1710.h
 * History:
 */


#ifndef _KCS_H_
#define _KCS_H_

#include "glib.h"

/* ****************************************************************************
�����ṩ�ĺ궨��
 ***************************************************************************** */
#define MAX_KCS_NUM 4

/* ****************************************************************************
���ݽṹ����
**************************************************************************** */
#pragma pack(1)
typedef struct tag_kcs_buffer_info_s {
    guint32 id;
    guint32 timeout; /* ��ʱʱ�䣬��Χ[0-65535]����λjiffies */
    gchar *buffer;
    guint32 len;
    gint32 reserved;
} KCS_BUFFER_INFO_S;
#pragma pack()


/* ****************************************************************************
����ӿں�������, ���Ӷ�C++��֧��
**************************************************************************** */
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

gint32 kcs_init(guint32 channel_mask);
void kcs_clean(void);
gint32 kcs_read(KCS_BUFFER_INFO_S *info);
gint32 kcs_write(KCS_BUFFER_INFO_S *info);
gint32 kcs_setatn(gint32 enable);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif
