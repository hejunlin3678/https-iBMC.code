/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: adc_base.h
 * Author: h00168999
 * Create: 2018/12/22
 * Notes: adc_base.h
 * History:
 */

#ifndef _ADC_BASE_H_
#define _ADC_BASE_H_

#include "glib.h"

#define ADC_MAX_CHAN 16

/* �ο���ѹԴ */
typedef enum adc_volt_src_e {
    EXTERNAL_VOLT, /* �ⲿ�ο���ѹ */
    INTERNAL_VOLT  /* �ڲ��ο���ѹ */
} VOLT_REF_SRC;

/* ****************************************************************************
����ӿں�������, ���Ӷ�C++��֧��
**************************************************************************** */
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

extern gint32 adc_init(guint scan_rate, VOLT_REF_SRC volt_ref_src, guint volt_ref_val);
extern void adc_clean(void);
extern gint32 adc_read(gint chan_id, guint32 *val);


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif
