/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: ά������ģ�������
 * Author: h00168999
 * Create: 2018/12/22
 * Notes: maint_debug_error.h
 * History:
 */

#ifndef __MD_ERROR_H__
#define __MD_ERROR_H__

#include <glib.h>
#include "pme/common/mscm_err.h"  
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define MD_OK (0)
#define MD_EPARA DEF_ERROR_NUMBER(ERR_MODULE_ID_MD, -1)
#define MD_EINTER DEF_ERROR_NUMBER(ERR_MODULE_ID_MD, -2)
#define MD_ESOCK_CLOSE DEF_ERROR_NUMBER(ERR_MODULE_ID_MD, -3)
#define MD_EMSGFMT DEF_ERROR_NUMBER(ERR_MODULE_ID_MD, -4)
#define MD_ECMD_INVALID DEF_ERROR_NUMBER(ERR_MODULE_ID_MD, -5)
#define MD_ECMD_EXE DEF_ERROR_NUMBER(ERR_MODULE_ID_MD, -6)
#define MD_EBUSY DEF_ERROR_NUMBER(ERR_MODULE_ID_MD, -7)
#define MD_EPRIVILEGE DEF_ERROR_NUMBER(ERR_MODULE_ID_MD, -8)

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif
