/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: �ṩ��Ӧ��ģ���ά�����⶯̬��
 * Author: h00168999
 * Create: 2018/12/22
 * Notes: maint_debug_so.h
 * History:
 */

#ifndef __MD_SO_H__
#define __MD_SO_H__

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define LOG_MAX_SZ (1024)

#define CONNECT_TO_CLI ("connect_to_cli")
#define DECONNECT_TO_CLI ("deconnect_to_cli")
#define DLOG_OUTYPE ("dlog_outype")
#define DLOG_OUTLVL ("dlog_outlvl")
#define SAVE_DLOG_CFG ("save_dlog_cfg")
#define SET_TRACE_CFG ("set_trace_cfg")

#define debug_log(level, format, arg...)                            \
    do {                                                            \
        debug_log_func((level), __FILE__, __LINE__, format, ##arg); \
    } while (0) /* lint -restore */

/* ���Ӳ�����鿪�غ� */
#ifdef PME_SUPPORT_FORMAT_WARNING
#define FMT_CHECK(m, n) __attribute__((format(printf, m, n)))
#else
#define FMT_CHECK(m, n)
#endif

typedef enum { DLOG_ERROR, DLOG_INFO, DLOG_DEBUG, DLOG_MASS, DLOG_BUTT } DLOG_LEVEL_E;

typedef enum { SLOG_ERROR, SLOG_WARN, SLOG_INFO, SLOG_BUTT } SLOG_LEVEL_E;

typedef enum { MLOG_ERROR, MLOG_WARN, MLOG_INFO, MLOG_BUTT } MLOG_LEVEL_E;

/* ��־���� */
typedef enum {
    LOG_TYPE_DEBUG,
    LOG_TYPE_OPERATE,
    LOG_TYPE_STRATEGY,
    LOG_TYPE_MASS_OPERATE,
    LOG_TYPE_MAINT,
    LOG_TYPE_BUTT
} LOG_TYPE_E;

/* ��־Ԫ�� */
#define LOG_TIME (0x01)
#define LOG_MOD (0x02)
#define LOG_US_TIME (0x04)

extern gint32 init_md_so(void);

/* ��Ҫʹ��dbg_log��ʹ��debug_log�� */
extern void dbg_log(DLOG_LEVEL_E level, const gchar *fmt, ...) FMT_CHECK(2, 3);

extern void debug_log_func(DLOG_LEVEL_E level, const gchar *file_name, guint32 line_num,
    const gchar *fmt, ...) FMT_CHECK(4, 5);

extern void strategy_log(SLOG_LEVEL_E level, const gchar *fmt, ...) FMT_CHECK(2, 3);

extern void operation_log(const gchar *interface, const gchar *username, const gchar *client,
    const gchar *target, const gchar *fmt, ...) FMT_CHECK(5, 6);

extern void mass_operation_log(const gchar *interface, const gchar *username, const gchar *client,
    const gchar *target, const gchar *fmt, ...) FMT_CHECK(5, 6);

extern void maintenance_log(MLOG_LEVEL_E level, const gchar *fmt, ...) FMT_CHECK(2, 3);

/* App�Զ�����־ */
extern gint custom_log_init(gchar *log_name, guint32 package_size, guint64 privilege);
extern void custom_log(const gchar *log_name, guint8 component,
    const gchar *fmt, ...) FMT_CHECK(3, 4);

/* method_log ת��APP ��¼�������ã���¼������־ */
extern void method_operation_log(GSList* caller_info, const gchar *target,
    const gchar *fmt, ...) FMT_CHECK(3, 4);
extern void proxy_method_operation_log(GSList* caller_info, const gchar *target,
    const gchar *fmt, ...) FMT_CHECK(3, 4);

extern void security_log(const gchar *fmt, ...) FMT_CHECK(1, 2);

extern void console_printf(const gchar *fmt, ...) FMT_CHECK(1, 2);
extern void debug_printf(const gchar *fmt, ...) FMT_CHECK(1, 2);

extern gint32 module_trace(const gchar *fmt, ...) FMT_CHECK(1, 2);
extern gint is_module_trace_enable(void);

/* ���� */
extern gint32 get_method_operation_log_info(GSList *caller_info, const gchar **interface_nm, const gchar **usr_nm,
    const gchar **client);
extern gint32 clear_log(LOG_TYPE_E log_type);

/* ��ȡ��־�ļ���ѹ��������С */
extern gint32 get_log_file_package_size(gchar *log_name, guint32 *package_size);

/* ��ȡdbg log��־���� */
extern gint get_dbg_log_outlvl(void);

/* ����־�ļ�ˢ�µ��洢���� */
extern void file_log_flush(void);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif
