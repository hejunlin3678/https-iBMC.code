/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: dfhas.c ��ͷ�ļ�
 * Author: s00120510
 * Create: 2018/12/22
 * Notes: dfhas.h
 * History:
 */

#ifndef __DFHAS_H__
#define __DFHAS_H__


#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */


#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif /* __DFHAS_H__ */
