/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: mscm_tar.h
 * Author: h00168999
 * Create: 2018/12/22
 * Notes:
 * History:
 */

#ifndef __MSCM_TAR_H__
#define __MSCM_TAR_H__
#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

extern gint32 tar_bzip2(const guchar *pucdirfilename, const guchar *pucoutfilename);
extern gint32 tar_unzip(const guchar *pucdirfilename, const guchar *pucdirname);
extern gint32 tar_gzip(const guchar *pucdirfilename, const guchar *pucoutfilename);
extern gint32 tar_gzip_pack(const guchar *filepath, const guchar *pucdirfilename, const guchar *pucoutfilename);
#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */
#endif
