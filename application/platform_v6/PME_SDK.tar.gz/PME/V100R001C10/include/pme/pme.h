/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2018-2019. All rights reserved.
 * Description: pme���й�����ͷ�ļ���ͳһ��ڵ�
 * Author: h00168999
 * Create: 2018/12/22
 * Notes: pme.h
 * History:
 */


#ifndef __PME_H__
#define __PME_H__
/* glib support */
#include <string.h>
#include <glib-2.0/glib.h>
#include <glib-2.0/glib/gprintf.h>
#include <glib-2.0/glib/gstdio.h>

#include "dflib/template.h"

/* file_manage */
#include "file_manage/file_manage.h"
#include "persistance/persistance.h"

/* ������ͷ�ļ� */
#include "dfrpc/df_rpc.h"
#include "dflib/dflerr.h"
#include "dflib/dflib.h"
#include "xml_parser/xml_parser.h"

#include "debug/maint_debug_so.h"
#include "pflash_drv/pflash_driver.h"

/* ??????ͷ?ļ? */
#include "common/mscm_vos.h"
#include "common/mscm_macro.h"


/* add drivers lib  */
#include "drivers/i2c_base.h"
#include "drivers/cpld_upg.h"
#include "drivers/gpio_base.h"
#include "drivers/wdt.h"
#include "drivers/spi_base.h"
#include "drivers/localbus_base.h"
#include "drivers/ipmb.h"
#include "drivers/bt.h"
#include "drivers/kcs.h"
#include "drivers/sol.h"
#include "drivers/uart.h"
#include "drivers/sys_info.h"
#include "drivers/mdio_base.h"
#include "drivers/sd_raid.h"
#include "drivers/dfx_api.h"
#include "drivers/mctp.h"
#include "drivers/mmc_base.h"
#include "drivers/efuse.h"
#include "drivers/trng.h"
#include "drivers/canbus_base.h"

/* PME�����Է�������  */
#include "property_method/property_method.h"

#include "ipmi/common_ipmi.h"
#include "ipmi/ipmi_oem.h"

/* ������������,��Ҫ�ҵ�����ͷ�ļ�--BTD */
/* IPMI�����DATA�ֶι����������� */
#define  IPMI_DATA_FILTER_LEN    (128)
#define  MODULE_OK               (VOS_OK)
#define  MODULE_ERR              (VOS_ERR)
#define  MAX_POSSIBLE_IPMI_FRAME_LEN    (512)
#define  REBOOT_BMC_TIMER_TIME          (100) /* Unit:ms */
#define  PICMG_IDENTIFIER               (0x00)
#define  PICMG_EXTENSION_VERSION        (0x22)
#define  PME_CHASSIS_ADDR               (0x20)

enum {
    BMC_DISABLE = 0,
    BMC_ENABLE
};


/* �쳣ʱ��ʽ�����--BTD, Ӧ��debugģ��ͳһ���幫����ʽ */
#define  DB_STR_FORMAT_ERR           ("Ret:%d\n")
#define  DB_STR_PARAM_POINTER_NULL   ("Param pointer is null!\n")
#define  DB_STR_DFL_HANDLE_NULL      ("get dfl handle is null!\n")
#define  DB_STR_FILE_NAME_LEN_ERR    ("FileNameLen:%d is err!\n")
#define  DB_STR_GET_DFL_INPUT_ERR    ("get dfl input param is null!\n")
#define  DB_STR_GET_PROPERTY_NULL    ("get property addr is null!\n")
#define  DB_STR_GET_SRC_DATA_FAIL    ("get_ipmi_src_data fail!\n")
#define  DB_STR_MUNU_ID_ERR          ("judge_manu_id_valid fail(Ret:0x%x)!\n")
#define  DB_STR_SET_PROPERTY_ERR     ("dfl_set_property_value fail(Ret:%d)!\n")

#define  COMP_CODE_HPM_IN_PROGRESS   (0x80)

/* LED״̬ */
#define LED_OFF (0)             /* �� */
#define ON_900_OFF_100 (3)
#define ON_100_OFF_900 (4)
#define ON_500_OFF_500 (5)      /* UID����ʱ����ʱ��״̬ */
#define ON_250_OFF_250 (6)
#define ON_100_OFF_100 (7)
#define LED_ON (0xFF)           /* �� */

#endif /* __PME_H__ */

