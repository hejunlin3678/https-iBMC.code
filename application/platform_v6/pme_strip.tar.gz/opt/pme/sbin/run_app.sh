#!/bin/sh 

# This scripts read a text file line by line, then do something.

# May you do good and not evil.
# May you find forgiveness for yourself and forgive others.
# May you share freely, never taking more than you give.

# author: 
# date: Thu Mar 13 20:22:28 CST 2014
# version: 0.8.0-1


#global var define
G_SRC="/opt/pme/extern/app.list"
G_APP_DIR="/opt/pme/apps"
G_LEGACY_APP_DIR="/opt/bmc/apps/legacy"

for line in $(grep -Ev "^$|#" "$G_SRC")
do
    if [ -d "$G_LEGACY_APP_DIR/$line" ];then
        cd "$G_LEGACY_APP_DIR/$line"
    else
        cd "$G_APP_DIR"
    fi
    # do something what ever.
    ./${line} &
done

#check and restart app
for line in $(grep -Ev "^$|#" "$G_SRC")
do
    count=`ps -ef | grep ${line} | grep -v "grep" | wc -l`
    if [ $count == 0 ]
    then
        if [ -d "$G_LEGACY_APP_DIR/$line" ];then
            cd "$G_LEGACY_APP_DIR/$line"
        else
            cd "$G_APP_DIR"
        fi
        ./${line} &
        echo "${line} retry..."
    fi
done

exit 0

