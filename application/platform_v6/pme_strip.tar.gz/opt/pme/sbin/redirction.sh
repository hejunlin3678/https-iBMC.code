#!/bin/sh

APPEND="--append"   
REDIR="--redir"  
FILENAME=
CMD=
FLAG=0

for arg in $@
do 
    if [ $FLAG -gt 0 ] ; then
        FILENAME=$arg
        break
    fi
    
    if [ "$arg" = "$APPEND" ] ; then
        FLAG=1
    elif [ "$arg" = "$REDIR" ] ; then
        FLAG=2
    else
        CMD="$CMD $arg"
    fi
done

if [ $FLAG -eq 1 ] ; then
    eval $CMD >> $FILENAME 2>&1
elif [ $FLAG -eq 2 ] ; then
    eval $CMD > $FILENAME 2>&1
else
    echo "parameter error"
fi
