#!/bin/sh 

# This scripts provide common function.

# May you do good and not evil.
# May you find forgiveness for yourself and forgive others.
# May you share freely, never taking more than you give.

# author: 
# date: Thu Mar 13 20:22:28 CST 2014
# version: 0.8.0-1


#global var define
G_SRC="/opt/pme/extern/app.list"

count_app()
{
    echo $(grep -Ev "^$|#" "$G_SRC" | wc -l)
}
