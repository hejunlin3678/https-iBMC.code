#!/bin/sh

# This scripts insmod product based drivers.
# author: 
# date: Wed Sep 23 14:04:54 CST 2015
# version: 0.8.0-1

# do nothing now, product based drivers insmod with scripts /opt/pme/extern/insmod_driver.sh

